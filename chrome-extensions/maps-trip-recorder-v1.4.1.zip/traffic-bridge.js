const TRAFFIC_MESSAGE = "MAPS_TRIP_RECORDER_DATA";
const TRAFFIC_REQUEST = "MAPS_TRIP_RECORDER_REQUEST";
const TRAFFIC_CLEAR = "MAPS_TRIP_RECORDER_CLEAR";

async function publishTrips() {
  if (!location.pathname.startsWith("/personal/traffic")) return;
  const { trips = [], monitoredRoutes = [] } = await chrome.storage.local.get(["trips", "monitoredRoutes"]);
  window.postMessage({ type: TRAFFIC_MESSAGE, trips, monitoredRoutes }, location.origin);
}

window.addEventListener("message", (event) => {
  if (event.source !== window || event.origin !== location.origin) return;
  if (event.data?.type === TRAFFIC_REQUEST) publishTrips();
  if (event.data?.type === TRAFFIC_CLEAR) {
    chrome.storage.local.remove(["trips", "lastAutoSignature"]).then(() => publishTrips());
  }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && (changes.trips || changes.monitoredRoutes)) publishTrips();
});

document.addEventListener("DOMContentLoaded", publishTrips, { once: true });
