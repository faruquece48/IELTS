const DHAKA_ROADS = [
  { id: "airport-railway-gabtoli", roadName: "Airport Railway Station → Gabtoli", start: "Airport Railway Station, Dhaka", destination: "Gabtoli Bus Terminal, Dhaka", startAliases: ["airport railway station"], destinationAliases: ["gabtoli bus terminal"] },
  { id: "airport-railway-kamalapur", roadName: "Airport Railway Station → Kamalapur", start: "Airport Railway Station, Dhaka", destination: "Kamalapur Railway Station, Dhaka", startAliases: ["airport railway station"], destinationAliases: ["kamalapur railway station", "komolapur railway station"] },
  { id: "airport-road", roadName: "Airport Road", start: "Hazrat Shahjalal International Airport, Dhaka", destination: "Kakoli Bus Stop, Dhaka", startAliases: ["hazrat shahjalal international airport", "dhaka airport"], destinationAliases: ["kakoli", "kakoli bus stop"] },
  { id: "mirpur-road", roadName: "Mirpur Road", start: "Gabtoli Bus Terminal, Dhaka", destination: "Science Lab, Dhaka" },
  { id: "kazi-nazrul-islam-avenue", roadName: "Kazi Nazrul Islam Avenue", start: "Farmgate, Dhaka", destination: "Shahbag, Dhaka" },
  { id: "begum-rokeya-sarani", roadName: "Begum Rokeya Sarani", start: "Mirpur 10 Roundabout, Dhaka", destination: "Agargaon, Dhaka" },
  { id: "pragati-sarani", roadName: "Pragati Sarani", start: "Kuril Bishwa Road, Dhaka", destination: "Rampura Bridge, Dhaka" },
  { id: "sat-masjid-road", roadName: "Sat Masjid Road", start: "Mohammadpur Bus Stand, Dhaka", destination: "Jigatola Bus Stand, Dhaka", startAliases: ["mohammadpur bus stand"], destinationAliases: ["jigatola", "zigatola"] },
  { id: "gulshan-avenue", roadName: "Gulshan Avenue", start: "Gulshan 2 Circle, Dhaka", destination: "Gulshan 1 Circle, Dhaka", startAliases: ["gulshan 2", "gulshan 2 circle", "gulshan 2 cir"], destinationAliases: ["gulshan 1", "gulshan 1 circle", "gulshan 1 cir"] },
  { id: "hatirjheel-road", roadName: "Hatirjheel Road", start: "Police Plaza Concord, Dhaka", destination: "Rampura Bridge, Dhaka" },
].map((road) => {
  const params = new URLSearchParams({ api: "1", origin: road.start, destination: road.destination, travelmode: "driving" });
  return { ...road, key: `dhaka-road:${road.id}`, url: `https://www.google.com/maps/dir/?${params}`, builtIn: true };
});
