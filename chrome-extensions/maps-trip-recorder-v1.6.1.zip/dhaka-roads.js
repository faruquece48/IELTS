const DHAKA_ROADS = [
  { id: "airport-road", roadName: "Airport Road", start: "Hazrat Shahjalal International Airport, Dhaka", destination: "Kakoli Bus Stop, Dhaka" },
  { id: "mirpur-road", roadName: "Mirpur Road", start: "Gabtoli Bus Terminal, Dhaka", destination: "Science Lab, Dhaka" },
  { id: "kazi-nazrul-islam-avenue", roadName: "Kazi Nazrul Islam Avenue", start: "Farmgate, Dhaka", destination: "Shahbag, Dhaka" },
  { id: "begum-rokeya-sarani", roadName: "Begum Rokeya Sarani", start: "Mirpur 10 Roundabout, Dhaka", destination: "Agargaon, Dhaka" },
  { id: "pragati-sarani", roadName: "Pragati Sarani", start: "Kuril Bishwa Road, Dhaka", destination: "Rampura Bridge, Dhaka" },
  { id: "sat-masjid-road", roadName: "Sat Masjid Road", start: "Mohammadpur Bus Stand, Dhaka", destination: "Jigatola Bus Stand, Dhaka" },
  { id: "gulshan-avenue", roadName: "Gulshan Avenue", start: "Gulshan 2 Circle, Dhaka", destination: "Gulshan 1 Circle, Dhaka" },
  { id: "hatirjheel-road", roadName: "Hatirjheel Road", start: "Police Plaza Concord, Dhaka", destination: "Rampura Bridge, Dhaka" },
  { id: "bijoy-sarani", roadName: "Bijoy Sarani–Old Airport Road", start: "Jahangir Gate, Dhaka", destination: "Farmgate, Dhaka" },
  { id: "mayor-hanif-flyover", roadName: "Mayor Mohammad Hanif Flyover", start: "Gulistan, Dhaka", destination: "Jatrabari, Dhaka" },
].map((road) => {
  const params = new URLSearchParams({ api: "1", origin: road.start, destination: road.destination, travelmode: "driving" });
  return { ...road, key: `dhaka-road:${road.id}`, url: `https://www.google.com/maps/dir/?${params}`, builtIn: true };
});
