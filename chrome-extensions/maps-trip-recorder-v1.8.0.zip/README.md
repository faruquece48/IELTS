# Maps Trip Time Recorder

## Install in Chrome

1. Open `chrome://extensions`.
2. Turn on **Developer mode**.
3. Click **Load unpacked**.
4. Select this `maps-trip-recorder` folder.
5. Open Google Maps, choose **Directions**, and enter a starting point and destination.
6. Wait for the route results to appear. The extension compares the displayed alternatives, records only the route with the shortest travel time and its matching distance, and saves another snapshot every 60 seconds while Chrome remains open.
7. Click the extension icon to review history, edit and save a separate copy, or export CSV.

The extension monitors exactly ten Dhaka routes: the two original Airport Railway Station routes plus Airport Road, Mirpur Road, Kazi Nazrul Islam Avenue, Begum Rokeya Sarani, Pragati Sarani, Sat Masjid Road, Gulshan Avenue, and Hatirjheel Road.

The extension stores trip records locally in Chrome. Every one-minute shortest-route snapshot is retained so changes in traffic time can be reviewed later. While Chrome is open, it revisits the ten Dhaka corridors and saved journeys in inactive tabs every minute, waits for route details to load, records the fastest displayed route, and closes the tabs. You do not need to keep Google Maps open. Between scheduled snapshots, duplicate records caused by ordinary Maps page redraws are ignored. Use **Export CSV** to download the history. If the extension was installed while Google Maps was already open, reload the Maps tab once.

The collector reuses one Google Maps tab in a minimized background window and rotates it through every monitored route. A startup lock prevents extension reloads from creating duplicate collector tabs. After a route is recorded, the same tab moves to the next route after a short pause. A 30-second fallback advances the tab if Maps fails to return a reading. Snapshot writes are serialized by the background worker so one route cannot overwrite another route's reading.

While a route is loading, an independent five-second readiness check looks for complete directions. This prevents Google Maps' continuous page updates from postponing the first snapshot indefinitely.

Traffic history is stored in `data/traffic-records.json` inside the website project instead of inside a Chrome profile. Keep the website running at `http://localhost:3000` while collecting. Every Chrome profile using the extension reads and writes the same file. Copying the complete project folder to another PC carries the history with it; run the website there and load the unpacked extension again.

Use the **Automatic collection** switch in the extension popup to pause or resume data collection. Pausing closes background collector tabs immediately and prevents open Maps tabs from creating automatic snapshots. Existing history is preserved, and manually saving a trip remains available.

Automatic snapshots estimate the share of the four Google Maps traffic colors (green, yellow, red, and maroon) from the rendered Maps tab. This image-based breakdown is free and requires no API key. It is marked as an estimate because nearby visible roads can contribute pixels. The extension uses Chrome's debugger capture permission so the same analysis can run in inactive collector tabs without bringing them to the foreground.

When `/personal/traffic` is opened on localhost, `127.0.0.1`, or a Vercel deployment, the extension automatically sends its saved history to that Traffic page. Reload both the extension and the Traffic tab after installing an updated version.
